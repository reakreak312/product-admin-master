<?php 
    include('connection.php'); 
    session_start();
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        $mycategory_name = mysqli_real_escape_string($db,$_POST['category_name']);
        $message = "";
        $sql = "INSERT INTO categorys (category_name) VALUES ('$mycategory_name')";
        if ($db->query($sql) === TRUE) {
            $message = "New record created successfully";
        } 
        else {
            $message = "Error: " . $sql . "<br>" . $db->error;
        }
        $_SESSION["isShow"] = true;
        $_SESSION["message"] = $message;
        header("location: ../product.php");
    }
?>